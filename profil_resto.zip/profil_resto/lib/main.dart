import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: RestaurantProfile(),
    );
  }
}

class RestaurantProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rm. Sedap Rasa'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Gambar Profil dari Asset
              Container(
                width: 150,
                height: 150,
                child: Image.asset('assets/images/makanan.jpg'), // Path yang benar
              ),
              SizedBox(height: 16),
              // Icon bar (Email, Map, Phone)
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    icon: Icon(Icons.email),
                    onPressed: () {},
                  ),
                  IconButton(
                    icon: Icon(Icons.map),
                    onPressed: () {},
                  ),
                  IconButton(
                    icon: Icon(Icons.phone),
                    onPressed: () {},
                  ),
                ],
              ),
              SizedBox(height: 16),
              // Deskripsi
              Text(
                'Deskripsi:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Restoran ini menyediakan berbagai masakan lezat dan halal.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16),
              // List Menu
              Text(
                'List Menu:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('- Nasi Goreng Spesial', textAlign: TextAlign.center),
                  Text('- Ayam Goreng', textAlign: TextAlign.center),
                  Text('- Sate Ayam', textAlign: TextAlign.center),
                ],
              ),
              SizedBox(height: 16),
              // Alamat
              Text(
                'Alamat:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18),
              ),
              SizedBox(height: 8),
              Text(
                'Jl. Merdeka No. 123, Semarang',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 16),
              // Jam Buka
              Text(
                'Jam Buka:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18),
              ),
              SizedBox(height: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text('Senin - Jumat: 08.00 - 21.00', textAlign: TextAlign.center),
                  Text('Sabtu - Minggu: 10.00 - 23.00', textAlign: TextAlign.center),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
