package com.example.profil_resto

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
